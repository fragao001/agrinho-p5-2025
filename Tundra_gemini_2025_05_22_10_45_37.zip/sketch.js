function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(135, 206, 235); // Céu azul

  drawSun();
  drawGround();
  drawTrees();
  drawBarn();
  drawAnimals();
  drawFence();
}

// Desenha o sol
function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(80, 80, 60, 60);
}

// Desenha o chão
function drawGround() {
  fill(34, 139, 34);
  rect(0, height * 0.75, width, height * 0.25);
}

// Desenha árvores
function drawTrees() {
  // Árvore 1
  fill(139, 69, 19);
  rect(150, height * 0.75 - 100, 20, 100);
  fill(34, 139, 34);
  ellipse(160, height * 0.75 - 120, 80, 80);
  
  // Árvore 2
  rect(400, height * 0.75 - 80, 20, 80);
  ellipse(410, height * 0.75 - 100, 70, 70);
}

// Desenha o celeiro
function drawBarn() {
  fill(178, 34, 34);
  rect(250, height * 0.75 - 100, 100, 100);
  fill(255);
  rect(290, height * 0.75 - 100, 20, 50); // Porta
  fill(255, 0, 0);
  triangle(250, height * 0.75 - 100, 350, height * 0.75 - 100, 300, height * 0.75 - 150); // Telhado
}

// Desenha alguns animais
function drawAnimals() {
  // Vaca
  fill(255);
  ellipse(100, height * 0.75 + 20, 40, 30); // corpo
  ellipse(80, height * 0.75 + 10, 20, 20); // cabeça
  fill(0);
  ellipse(75, height * 0.75 + 8, 3, 3); // olho
  fill(255);
  rect(90, height * 0.75 + 25, 10, 5); // patas
  
  // Porquinho
  fill(255, 192, 203);
  ellipse(500, height * 0.75 + 20, 30, 20); // corpo
  ellipse(485, height * 0.75 + 10, 15, 15); // cabeça
  fill(0);
  ellipse(480, height * 0.75 + 8, 2, 2); // olho
  fill(255);
  rect(495, height * 0.75 + 20, 5, 3); // patas
}

// Desenha a cerca
function drawFence() {
  stroke(139, 69, 19);
  strokeWeight(4);
  for (let x = 0; x <= width; x += 20) {
    line(x, height * 0.75, x, height);
  }
}